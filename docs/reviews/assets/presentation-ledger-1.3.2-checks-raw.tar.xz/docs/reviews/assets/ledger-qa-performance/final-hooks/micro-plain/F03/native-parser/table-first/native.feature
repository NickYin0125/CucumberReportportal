@reportportal_live @ledger_developer @F03 
Feature: Ledger developer F03
  Scenario Outline: table-first
    Given ledger combined "table-first":
      | key | value |
      | combined | <value> |
      """
      CONSTANT_DOC
      """

    Examples: Table-only substitution
      | value |
      | TABLE_ONLY_AMBER <other> |
      | TABLE_ONLY_BIRCH <other> |

